package io.swagger.api;

import io.swagger.model.Resultado;
import io.swagger.model.Repository;

import io.swagger.annotations.*;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import org.w3c.dom.Document;
import freemarker.template.Configuration;
import freemarker.template.Template;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2019-05-20T05:15:20.809-05:00")

@Controller
public class TransformApiController implements TransformApi {

	public ResponseEntity<Resultado> transform(

			@ApiParam(value = "transform de valores", required = true) @RequestBody Repository repository

	) {
		System.out.println("llego ");
		System.out.println("repository[" + repository.toString() + "]");

		String servicio = repository.getMetodo();

		String config = repository.getConfig();

		Configuration cfg = new Configuration();
		// Cargar plantilla
		Template template = null;
		String strRequest = null;
		HttpClient httpClient = null;
		XPathExpression expr;
		Resultado lFacturaResponse = new Resultado();
		try {
			System.out.println("antes de template");
			template = cfg.getTemplate(config);

			// Modelo de datos
			Map<String, Object> data = new HashMap<String, Object>();
			System.out.println("antes de validar consulta");
			if (servicio.equals("consulta")) {

				data.put("idFactura", String.format("%.0f", repository.getFactura().getIdFactura()));
			} else if (servicio.equals("pago")) {

				data.put("idFactura", String.format("%.0f", repository.getFactura().getIdFactura()));
				data.put("valorPagar", String.format("%.2f", repository.getFactura().getValor()));
			} else if (servicio.equals("compensacion")) {

				data.put("idFactura", String.format("%.0f", repository.getFactura().getIdFactura()));
				data.put("valorPagar", String.format("%.2f", repository.getFactura().getValor()));
			}

			// Crear mensaje SOAP HTTP
			StringWriter out = new StringWriter();
			template.process(data, out);
			strRequest = out.getBuffer().toString();

			// Crear la llamada al servidor
			httpClient = new DefaultHttpClient();
			HttpPost postRequest = new HttpPost(repository.getEndpoint());
			postRequest.addHeader("Accept", "text/xml");
			postRequest.addHeader("SOAPAction", repository.getAccion()); // nombre de accion definida e tabla

			StringEntity input = new StringEntity(strRequest);
			input.setContentType("text/xml; charset=utf-8");

			System.out.println(strRequest);

			postRequest.setEntity(input);

			// Tratar respuesta del servidor
			HttpResponse response = httpClient.execute(postRequest);
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException(
						"Error : Código de error HTTP : " + response.getStatusLine().getStatusCode());
			}

			// Obtener información de la respuesta

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			Document XMLDoc = factory.newDocumentBuilder().parse(response.getEntity().getContent());
			XPath xpath = XPathFactory.newInstance().newXPath();
			if (servicio.equals("consulta")) {
				expr = xpath.compile("//" + repository.getCampoValor());
				String result = String.class.cast(expr.evaluate(XMLDoc, XPathConstants.STRING));
				lFacturaResponse.setValorRespuesta(new Double(result));
			} else if (servicio.equals("pago")) {
				expr = xpath.compile("//" + repository.getCampoMensaje());
				String result = String.class.cast(expr.evaluate(XMLDoc, XPathConstants.STRING));
				lFacturaResponse.setMensaje(result);

			} else if (servicio.equals("compensacion")) {
				expr = xpath.compile("//" + repository.getCampoMensaje());
				String result = String.class.cast(expr.evaluate(XMLDoc, XPathConstants.STRING));
				lFacturaResponse.setMensaje(result);

			}

			return ResponseEntity.ok(lFacturaResponse);

		} catch (Exception e) {
			System.out.println("error solicitud");
			e.printStackTrace();
			lFacturaResponse = new Resultado();
			lFacturaResponse.setMensaje("Error en proceso intente mas tarde");
			return ResponseEntity.badRequest().body(null);
		}
	}
}
