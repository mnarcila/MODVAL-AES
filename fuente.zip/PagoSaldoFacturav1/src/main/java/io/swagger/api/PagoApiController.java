package io.swagger.api;

import io.swagger.model.Resultado;
import io.swagger.model.Factura;

import io.swagger.annotations.*;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.client.RestTemplate; 

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2019-05-20T00:01:55.157-05:00")

@Controller
public class PagoApiController implements PagoApi {
	@Autowired
	RestTemplate restTemplate;

	public ResponseEntity<Resultado> pago(

			@ApiParam(value = "Pago de valores", required = true) @RequestBody Factura factura

	) {

		System.out.println("ConsultaApi [" + factura + "]");
		String lEndPoint = "http://10.0.75.1:9003/enrutarFactura/pago";

		System.out.println("lEndPoint[" + lEndPoint + "]");
		// consultar servicio de adaptador
		Resultado lFacturaResponse = restTemplate.postForEntity(lEndPoint, factura, Resultado.class).getBody();
		// prueba del endpoint

		if (lFacturaResponse != null) {
			return ResponseEntity.ok(lFacturaResponse);

		} else {
			return ResponseEntity.badRequest().body(null);
		}
	}

}
