package io.swagger.api;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiParam;
import io.swagger.model.Repository;
import io.swagger.model.Resultado;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2019-05-19T19:29:09.570-05:00")

@Controller
public class TransformApiController implements TransformApi {

	@Autowired
	ObjectMapper objectMapper;

	public ResponseEntity<Resultado> transform(

			@ApiParam(value = "transform de valores", required = true) @RequestBody Repository repository

	) {
		Resultado lFacturaResponse = new Resultado();
		System.out.println("TransformApiController:: ");
		System.out.println("repository[" + repository.toString() + "]");
		DefaultHttpClient httpclient = new DefaultHttpClient();
		try {

			// specify the host, protocol, and port

			HttpHost target = new HttpHost("ec2-34-200-223-89.compute-1.amazonaws.com", 9090, "http");

			// specify the get request
			HttpGet getRequest = new HttpGet("/api/domiciliacion/factura?fid=ABCD12345");

			HttpResponse httpResponse = httpclient.execute(target, getRequest);
			HttpEntity entity = httpResponse.getEntity();

			if (entity != null) {

				// System.out.println(EntityUtils.toString(entity));

				BufferedReader br = new BufferedReader(new InputStreamReader(entity.getContent()));
				String line = null;
				String output = "";
				while ((line = br.readLine()) != null) {

					output = output.concat(line);

				}
				System.out.println("output:" + output);

				StringTokenizer str1 = new StringTokenizer(output, "\\{,\\}") ;
				while (str1.hasMoreTokens()) {
					String val = str1.nextToken().trim();
					System.out.println("::"+val);
					// Split the string at the underscore and do some stuff
				}

				HashMap<String, Object> result = new ObjectMapper().readValue(output, HashMap.class);

				Iterator it = result.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry pair = (Map.Entry) it.next();
					System.out.println("" + pair.getKey() + "|" + pair.getValue());
					repository.setCampoValor("valor");

					if (repository.getMetodo().equals("consulta")) {

						if (repository.getCampoValor().equals(pair.getKey())) {
							System.out.println("" + pair.getKey() + "|" + pair.getValue());
							String lValor = pair.getValue().toString();

							lFacturaResponse.setValorRespuesta(Double.parseDouble(lValor));
						}

					} else if (repository.getMetodo().equals("pago")) {
						if (repository.getCampoValor().equals(pair.getKey())) {
							System.out.println("" + pair.getKey() + "|" + pair.getValue());
							lFacturaResponse.setMensaje((String) pair.getValue());
						}
					}

				}

			}

			return ResponseEntity.ok(lFacturaResponse);

		} catch (Exception e) {
			System.out.println("error solicitud");
			e.printStackTrace();
			lFacturaResponse = new Resultado();
			lFacturaResponse.setMensaje("Error en proceso intente mas tarde");
			return ResponseEntity.badRequest().body(null);
		}
	}
}
