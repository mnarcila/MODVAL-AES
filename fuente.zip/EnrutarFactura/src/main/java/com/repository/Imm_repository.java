package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Mm_repository;
 


public interface Imm_repository  extends JpaRepository<Mm_repository, Integer>{

}
